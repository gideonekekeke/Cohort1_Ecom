import {createBrowserRouter} from "react-router-dom"
import WebLayout from "../Layout/WebLayout"
import HomePage from "../Pages/HomePage"
import ShopPage from "../Pages/ShopPage"
import SignInPage from "../Pages/SignInPage"
import MerchantCard from "../Components/MerchantCard"
import AgentMerchant from "../Components/AgentMerchant"


const Index = createBrowserRouter([
    {
        path:"/",
        element:<WebLayout/>,

        children:[
            {
                index:true,
                element:<HomePage/>
            },
            {
                path:"/shoppage",
                element:<ShopPage/>
            },
           {
            path:"/signin",
            element:<SignInPage/>
           },
           {
            path:"/merchantcard",
            element:<MerchantCard/>
           },
           {
            path:"/agent",
            element:<AgentMerchant/>
           }
        ]
    }
])

export default Index