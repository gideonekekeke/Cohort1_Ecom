export type Items = {
    id:string,
    image:string,
    title:string,
    price:string
}