import React from 'react'
import {AiOutlineSearch} from "react-icons/ai"
import {BsCart4} from "react-icons/bs"
import {Link} from "react-router-dom"

const Header :React.FC= () => {
  return (
    <div className='bg-white h-[100px] p-10 flex justify-between'>
        <div className='text-[#191919] ml-10'>
            <h2 className='font-extrabold text-5xl'>veras.</h2>
            <span>Casual Wear Store</span>
        </div>
        
        <div className='text-[#191919] mt-6 flex gap-20 text-2xl  mr-[70px]'>
            <nav>Home</nav>
            <nav>About</nav>
            <nav>Shop</nav>
            <nav>Blog</nav>
            <nav>Contact</nav>
        </div>
        <div className='text-black text-2xl  mr-3 flex gap-5 mt-6'>
            {<AiOutlineSearch/>}
            
            {<BsCart4/>}
            <Link to="/signin">
            <h6>LOG IN</h6>
            </Link>
        </div>
    </div>
  )
}

export default Header