import React from 'react'
import { Items } from './Types/AllTypes'

interface Iprops{
    props:Items
}




const Card :React.FC<Iprops>= ({props}) => {
  return (
    <div className="">
        <div className='w-[350px] text-[#191919] min-h-[500px]  p-6 bg-white '>
        <img src={props?.image}/>
            <div className='text-2xl font-bold '>id~:{props?.id}
            
            <div>title~:{props?.title}</div>
            <div>price~:{props?.price}</div>
            </div>
            <div className='flex gap-6 text-[#191919]'>
                <button className='bg-[#DAD1D4]'>+</button>
                <button className='bg-[#DAD1D4]'>-</button>
            </div>
            
            

        </div>

        

    </div>
  )
}

export default Card