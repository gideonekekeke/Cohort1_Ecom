import React from 'react'
import pic from "../assets/tshirt.png"
import data from "../Components/Items.json"
import Card from '../Components/Card'

const ShopPage :React.FC= () => {
  return (
    <div className='min-h-full w-screen bg-[#F1F1F1] mt-10'>
        <div className='flex p-[30px] h-[500px]  bg-[#DAD1D4]  justify-evenly items-center'>
            <div className='h-[300px] w-[400px]'><img className='object-cover h-[400px] ' src={pic}/></div>
            <h1 className='text-9xl font-extrabold text-[#191919]'>Shop Page</h1>
        </div>
        <div className='flex flex-wrap gap-4 p-[20px]  mt-[30px]'>
            {data?.map((props)=>(
                <Card
                props = {props}
                />
                
                
            
            ))}
        </div>
        <div className='mt-[18px] text-[#191919] gap-8 flex'>
            <button className='w-[250px] h-[70px] bg-white p-6 rounded-[10px]  border-black'>CONTINUE SHOPPING</button>
            <button className='w-[250px] h-[70px] bg-white p-6 rounded-[10px]'>VIEW CART AND CHECKOUT</button>
        </div>


    </div>
  )
}

export default ShopPage