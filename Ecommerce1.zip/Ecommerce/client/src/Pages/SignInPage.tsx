import React from 'react'

const SignInPage:React.FC = () => {
  return (
    <div className='w-[500px] h-[600px] border text-gray bg-white flex flex-col items-center justify-center mt-6 rounded-[15px]'>
         <h1 className='text-black '>Log In</h1>
         <br/>
         <br/>
        
        <form>
             
            <div className='flex flex-col'>
                <span>Email</span>
                <input className='h-[40px] w-[300px] p-3 mb-5 bg-white border rounded-[5px] text-gray' placeholder='enter your email'/>
                
            </div>
            <div className='flex flex-col'>
                <span>PassWord</span>
                <input className='h-[40px] w-[300px] p-3 mb-5 bg-white border rounded-[5px] text-gray' placeholder='enter your password'/>
                
            </div>
            <div className='flex flex-col'>
                <span>Confirm PassWord</span>
                <input className='h-[40px] w-[300px] p-3 mb-5 bg-white border rounded-[5px] text-gray' placeholder='confirm password'/>
                
            </div>
            
            <button>Submit</button>
            
            <p className='mt-6 text-red'>forgot password?</p>
        </form>
    </div>
  )
}

export default SignInPage
